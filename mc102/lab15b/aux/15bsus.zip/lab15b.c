/*
	Aluno: Leonardo de Oliveira Ramos
	RA: 171941
	Sala: mc102r
	Professor: Zanoni Dias
*/

#include <stdio.h>
#include <stdlib.h>

void melhorIndice(int **vet, int N, int *ind, int *l) {
	int i, j, k;
	for(i=0;i<N;i++){
		for(j=0;j<N;j++){
			if(vet[1][i] == vet[0][j] - 1 && i!=j){
/*
				printf("%d encaixa por tras de %d\n", i, j);
				*/
				*ind = i;
				*l = j;
				for(k=0;k<N;k++){
					if(vet[0][i] == vet[1][k]+1 && i!=k && k==j-1){
/*
						printf("%d encaixa na frente de %d\n", i, k);
						*/
						*l = j;
						*ind = i;
						return;
					}
				}
			}
		}
	}
	return;
}

void inserIntervalo(int **V, int ind, int l){
	int i, auxZero, auxUm;

	auxZero = V[0][ind];
	auxUm = V[1][ind];
	
	if(ind>l){
		for(i=ind-1;i>=l;i--){
			V[0][i+1] = V[0][i];
			V[1][i+1] = V[1][i];
		}
		V[0][i+1] = auxZero;
		V[1][i+1] = auxUm;

	}else{
		for(i=ind;(i<l-1);i++){
			V[0][i] = V[0][i+1];
			V[1][i] = V[1][i+1];
		}
		
		V[0][i] = auxZero;
		V[1][i] = auxUm;		
	}


	

}

void retiraSequencias(int **V, int *N){
	int i, j=0;

	for(i=1;i<*N;i++){
		while(i<*N && V[0][i] == V[1][i-1] + 1){
			V[1][j] = V[1][i];
			i++;
		}
		if(i<*N){
			j++;
			V[0][j] = V[0][i];
			V[1][j] = V[1][i];
		}
	}
	*N = j+1;
	
}

int dSort(int **V, int N){
	int dist=0, ind, l;

	while(N > 1){
		retiraSequencias(V, &N);
		if(N > 1){
			dist++;
			melhorIndice(V, N, &ind, &l);
			inserIntervalo(V, ind, l);
		}
	}

	return dist;
}

int main(){
	int N, **V, i, distancia=0;

	scanf(" %d", &N);


	V = malloc(2 * sizeof(int*));
	for(i=0;i<2;i++){
		V[i] = malloc(N * sizeof(int));
	}

	for(i=0;i<N;i++){
		scanf(" %d", &V[0][i]);
		V[1][i] =	 V[0][i];  
	}

	distancia = dSort(V, N);

	printf("%d\n", distancia);

	for(i=0;i<2;i++)
		free(V[i]);
	free(V);
	return 0;
}
