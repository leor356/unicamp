/*
	Aluno: Leonardo de Oliveira Ramos
	RA: 171941
	Sala: mc102r
	Professor: Zanoni Dias
*/

#include <stdio.h>
#include <stdlib.h>

int insertion(int vet[], int i) {
	int j, aux = vet[i], mudou=0;
	for (j = i - 1; (j >= 0) && (vet[j] > aux); j--){
		vet[j + 1] = vet[j];
		mudou=1;
	}
	vet[j + 1] = aux;
	return mudou;
}

int dSort(int *V, int N){
	int i, dist=0;
	for(i=0;i<N;i++){
		dist += insertion(V, i);
	}

	return dist;
}

int main(){
	int N, *Vaux, *V, i, j=0, distancia=0;

	scanf(" %d", &N);

	V = malloc(N * sizeof(int));
	Vaux = malloc(N * sizeof(int));

	for(i=0;i<N;i++){
		scanf(" %d", &Vaux[i]);
	}
	for(i=0;i<N;i++){
		V[j] = Vaux[i];
		if(j==0 || (Vaux[i] != Vaux[i-1]+1)){
			j++;
		}
	}

	N=j;

	distancia = dSort(V, N);

/*	printf("%d\n", N);

	for(i=0;i<N;i++){
		printf("%d ", V[i]);
	}
	printf("\n");*/
	printf("%d\n", distancia);

	free(Vaux);
	free(V);
	return 0;
}
