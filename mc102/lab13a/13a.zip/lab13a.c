/*
  Aluno: Leonardo de Oliveira Ramos
  RA: 171941
  Sala: mc102r
  Professor: Zanoni Dias
*/

#include <stdio.h>
#include <stdlib.h>

int calculAltura(){
	int alturaLocal, altura=0, subBombas;

	scanf("%d ", &subBombas);

	if(subBombas == 0)
		return 0;

	while(subBombas > 0){

		/*printf("subBombas %d ", subBombas);*/

		alturaLocal = calculAltura() + 1;

		/*printf("altura %d\n", alturaLocal);*/

		if(alturaLocal > altura)
			altura = alturaLocal;
		subBombas--;
	}

	return altura;
}

int main(){
	int altura;

  altura = calculAltura() + 1;
  
  printf("%d\n", altura);

  return 0;
}
